import type { NextApiRequest, NextApiResponse } from "next";
import crypto from "crypto";
import { Buffer } from "buffer";
import dbConnect from "@/lib/mongodb";
import Verification from "@/models/Verification";

function decryptToken(token: string, secret: string): any {
  try {
    const [ivBase64, encrypted] = token.split(":");

    if (!ivBase64 || !encrypted) throw new Error("Token format is invalid");

    const iv = Buffer.from(ivBase64, "base64");
    const key = crypto.createHash("sha256").update(secret).digest();

    const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = decipher.update(encrypted, "base64", "utf8");
    decrypted += decipher.final("utf8");

    const parsed = JSON.parse(decrypted);
    return parsed;
  } catch (err) {
    console.error("❌ Decryption failed:", err instanceof Error ? err.message : err);
    return { error: err instanceof Error ? err.message : String(err) };
  }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { token } = req.body;
  
  if (!token) {
    return res.status(400).json({ error: "Token is required" });
  }

  const SECRET = process.env.SHORTNER_TOKEN_SECRET?.replace(/^"|"$/g, "");
  if (!SECRET) {
    return res.status(500).json({ error: "Server configuration error" });
  }

  // Decrypt and validate token
  const payload = decryptToken(token, SECRET);
  if (!payload || payload.error) {
    return res.status(400).json({ error: "Invalid verification token" });
  }

  // Check expiration
  const nowTimestamp = Math.floor(Date.now() / 1000);
  if (payload.exp && nowTimestamp >= payload.exp) {
    return res.status(400).json({ error: "Verification token has expired" });
  }

  try {
    // Connect to database
    await dbConnect();
    
    // Find verification document
    const verification = await Verification.findOne({ anon_id: payload.anon_id });
    if (!verification) {
      return res.status(400).json({ error: "Verification not found" });
    }

    // Check if already verified for this batch
    const verifiedBatch = verification.verifiedBatch || [];
    const now = new Date();
    const alreadyVerified = verifiedBatch.some((vb: any) => 
      vb.batchId === payload.batchid && 
      vb.expireAt && 
      new Date(vb.expireAt) > now
    );
    
    if (alreadyVerified) {
      return res.status(200).json({ 
        success: true, 
        message: "Already verified for this batch" 
      });
    }

    // Insert new verification
    const nowDate = new Date();
    const expiredAt = new Date(nowDate.getTime() + 12 * 60 * 60 * 1000); // 12 hours from now
    const newVerified = {
      batchId: payload.batchid,
      verificationToken: token,
      verifiedAt: nowDate,
      expireAt: expiredAt,
    };
    
    // Remove any existing verification for this batch, then add new one
    await Verification.updateOne(
      { anon_id: payload.anon_id },
      { $pull: { verifiedBatch: { batchId: payload.batchid } } }
    );
    
    const result = await Verification.updateOne(
      { anon_id: payload.anon_id },
      { $push: { verifiedBatch: newVerified } }
    );

    console.log("✅ Verification completed by user action:", {
      anon_id: payload.anon_id,
      batchId: payload.batchid,
      timestamp: nowDate.toISOString()
    });

    return res.status(200).json({ 
      success: true, 
      message: "Verification completed successfully" 
    });

  } catch (error) {
    console.error("❌ Verification completion failed:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
}