import React, { Suspense } from "react";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import WatchClient from "./WatchClient";
import { checkBatchVerification, generateAnonId } from "@/lib/serverVerification";

interface PageProps {
  searchParams: { [key: string]: string | string[] | undefined };
}

export default async function WatchPage({ searchParams }: PageProps) {
  // Check if user is authenticated
  const cookieStore = await cookies();
  const token = cookieStore.get('accessToken')?.value;

  if (!token) {
    redirect('/auth');
  }

  // Get batchId from search params
  const batchId = searchParams.batchId as string;

  if (batchId) {
    // Check batch verification for watch page
    const verificationResult = await checkBatchVerification(batchId);

    if (verificationResult.needsVerification) {
      // Generate anon_id if not exists
      let anonId = verificationResult.anonId;
      if (!anonId) {
        anonId = generateAnonId();

      }

      // Redirect to key-generate page with anon_id and batchId
      redirect(`/key-generate?anon_id=${anonId}&batchId=${batchId}`);
    }
  }

  return (
    <Suspense fallback={<div>You Need to enable JavaScript.</div>}>
      <WatchClient />
    </Suspense>
  );
}
