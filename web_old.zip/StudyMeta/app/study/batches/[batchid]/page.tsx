import { Suspense } from "react";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import BatchDetailPage from "./BatchDetail";
import { checkBatchVerification, generateAnonId } from "@/lib/serverVerification";

interface PageProps {
  params: { batchid: string };
}

export default async function Page({ params }: PageProps) {
  const batchId = params.batchid;

  // Check if user is authenticated
  const cookieStore = await cookies();
  const token = cookieStore.get('accessToken')?.value;

  if (!token) {
    redirect('/auth');
  }

  // Check batch verification
  const verificationResult = await checkBatchVerification(batchId);

  if (verificationResult.needsVerification) {
    // Generate anon_id if not exists
    let anonId = verificationResult.anonId;
    if (!anonId) {
      anonId = generateAnonId();
    }
    redirect(`/key-generate?anon_id=${anonId}&batchId=${batchId}`);
  }

  return (
    <Suspense fallback={<div className="text-center p-4 text-red-600">Loading...</div>}>
      <BatchDetailPage />
    </Suspense>
  );
}
